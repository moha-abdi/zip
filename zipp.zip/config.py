from pyrogram import Client

# BINANCE KEYS ######
apiKey = "i720x4WBPtMPcdoXjRXsHUNTX2mu4Nkz2yU9lfZhnhfl2EpJPOz7yLeVgsmQl4F0"
apiSecret = "A8gOSSVwiEyL7IkVpNIteagwCGUtWxyJHlBMT3wAMdxygCm120FIaxW2mClwdi4O"


# TELEGRAM CONFIGURATION#####
api_id = (14007265)
api_hash = ("00d4a84c7577da1bfe41ba5ef04906c8")
bot_token = ("5333494845:AAHeZfFmzn6bc83Jbu55k_kX1yMX-uj3doI")
bot = Client(
    "mohaan-bot",
    api_id=api_id,
    api_hash=api_hash,
    bot_token=bot_token
)

app = Client("mohh", api_id=api_id, api_hash=api_hash)

# TELEGRAM IDS/USERNAMES #####
copyfrom = [-1001886241519]
copyto = "som_info"

# AMOUNT ####
investment = 7
leverage = 50

# SL AND TP PERCENT
sl = 1
tp = 0.6

# BUY OR SELL
buy = True
sell = False

# VOLUME
start = 0
end = 5

